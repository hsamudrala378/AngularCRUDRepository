# Employee Manager App

An Angular CRUD app to manage employee records.