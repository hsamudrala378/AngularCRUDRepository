import { Component } from '@angular/core';
@Component({ selector: 'app-root', template: '<app-employee></app-employee>' })
export class AppComponent {}